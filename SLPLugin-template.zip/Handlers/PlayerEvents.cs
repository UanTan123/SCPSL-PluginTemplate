﻿using Exiled.API.Features;
using Exiled.Events.EventArgs;
using UnityEngine;

namespace $safeprojectname$.Handlers
{
    public class PlayerEvents
    {
        public PlayerEvents(Plugin plugin) => this.plugin = plugin;
        private readonly Plugin plugin;

        public void OnJoin(JoinedEventArgs ev)
        {
            Log.Info($"{ev.Player.Nickname}({ev.Player.UserId}) has joined server!");//Server Log
            Map.Broadcast(5, $"{ev.Player.Nickname}({ev.Player.UserId}) has joined server!");//All players broadcast.
            ev.Player.Broadcast(5, "당신은 서버에 접속하였습니다.");//Event player broadcast.
        }

        public void OnLeft(LeftEventArgs ev)
        {
            if (ev.Player.Team == Team.SCP)
            {
                Log.Info("Scp has server left!");
                if (ev.Player.Role == RoleType.Scp049)//ex
                {
                    Map.Broadcast(5, $"<color=red>Scp 049 left!</color>");
                }
            }
        }
    }
}
