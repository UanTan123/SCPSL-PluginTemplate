﻿using Exiled.API.Features;
using Exiled.Events.EventArgs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Handlers
{
    public class ServerEvents
    {
        public ServerEvents(Plugin plugin) => this.plugin = plugin;
        private readonly Plugin plugin;

        public void OnWaitingForPlayers()
        {
            Log.Info("플레이어를 기다리는 중...");
        }

        public void OnRoundStart()
        {
            Log.Info("라운드 시작!");
        }

        public void OnRoundEnd(RoundEndedEventArgs ev)
        {
            Log.Info($"{ev.LeadingTeam}진영이 이겼습니다!, 라운드 재시작 까지 {ev.TimeToRestart}초!");
        }
    }
}
