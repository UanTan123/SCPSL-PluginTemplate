﻿using Exiled.API.Features;
using Exiled.Events.EventArgs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Handlers
{
    public class WarheadEvents
    {
        public WarheadEvents(Plugin plugin) => this.plugin = plugin;
        private readonly Plugin plugin;

        public void OnAlphaStart(StartingEventArgs ev)
        {
            Map.Broadcast(5, plugin.Config.custom.Replace("%player%", ev.Player.Nickname));//Config!
            ev.Player.Broadcast(5, plugin.Config.custom);
        }
    }
}
