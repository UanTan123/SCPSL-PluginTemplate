﻿using Exiled.API.Interfaces;
using Server = Exiled.Events.Handlers.Server;
using Player = Exiled.Events.Handlers.Player;
using MapEvents = Exiled.Events.Handlers.Map;
using Warhead = Exiled.Events.Handlers.Warhead;

namespace $safeprojectname$
{
    sealed public class Config : IConfig
    {
        public bool IsEnabled { get; set; } = true;

        public string custom { get; set; } = "Alpha Start! %player%";
    }
}
