﻿using Server = Exiled.Events.Handlers.Server;
using Player = Exiled.Events.Handlers.Player;
using MapEvents = Exiled.Events.Handlers.Map;
using Warhead = Exiled.Events.Handlers.Warhead;
using Exiled.API.Enums;
using Exiled.API.Features;
using $safeprojectname$.Handlers;
using System;
//template for sl plugin creator.
//Mod Loader : Exiled.
//template maker : UN10#7777(discord)

namespace $safeprojectname$
{
    public class Plugin : Plugin<Config>
    {

        private static readonly Lazy<Plugin> LazyInstance = new Lazy<Plugin>(() => new Plugin());
        public static Plugin Instance => LazyInstance.Value;

        public override PluginPriority Priority { get; } = PluginPriority.Low;

        public PlayerEvents player;
        public ServerEvents server;
        public WarheadEvents warhead;

        private Plugin()
        {
        }

        public override void OnEnabled()
        {
            Log.Info("Plugin On!");
            On();

            base.OnEnabled();
        }

        public override void OnDisabled()
        {
            Log.Info("Plugin Off!");
            Off();

            base.OnDisabled();
        }

        public void On()
        {
            player = new PlayerEvents(this);
            server = new ServerEvents(this);
            warhead = new WarheadEvents(this);

            Player.Joined += player.OnJoin;
            Player.Left += player.OnLeft;
            Server.WaitingForPlayers += server.OnWaitingForPlayers;
            Server.RoundStarted += server.OnRoundStart;
            Server.RoundEnded += server.OnRoundEnd;
            Warhead.Starting += warhead.OnAlphaStart;
        }

        public void Off()
        {
            Player.Joined -= player.OnJoin;
            Player.Left -= player.OnLeft;
            Server.WaitingForPlayers -= server.OnWaitingForPlayers;
            Server.RoundStarted -= server.OnRoundStart;
            Server.RoundEnded -= server.OnRoundEnd;
            Warhead.Starting -= warhead.OnAlphaStart;

            player = null;
            server = null;
            warhead = null;
        }
    }
}
